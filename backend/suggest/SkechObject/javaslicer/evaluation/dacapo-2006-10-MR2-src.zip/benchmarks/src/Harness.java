import dacapo.TestHarness;

public class Harness {
  public static void main(String[] args) {
    TestHarness.main(args);
    System.exit(0);
  }
}
